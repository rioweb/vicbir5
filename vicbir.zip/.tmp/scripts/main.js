'use strict';

console.log('\'Allo \'Allo!');
//# sourceMappingURL=main.js.map
